package com.salesianos.__modeladodatos2.repository;

import com.salesianos.__modeladodatos2.model.CursoOnline;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoOnlineRepository extends JpaRepository<CursoOnline, Long> {
}
