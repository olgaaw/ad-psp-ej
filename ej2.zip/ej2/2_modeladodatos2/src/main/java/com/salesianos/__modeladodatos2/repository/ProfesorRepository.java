package com.salesianos.__modeladodatos2.repository;

import com.salesianos.__modeladodatos2.model.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepository extends JpaRepository<Profesor, Long> {
}
