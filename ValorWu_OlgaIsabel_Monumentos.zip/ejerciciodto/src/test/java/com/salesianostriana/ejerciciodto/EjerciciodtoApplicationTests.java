package com.salesianostriana.ejerciciodto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciodtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
